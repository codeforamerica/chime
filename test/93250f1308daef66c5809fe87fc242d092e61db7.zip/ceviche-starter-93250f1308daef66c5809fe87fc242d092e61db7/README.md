# ceviche-starter
Project Ceviche needs a generic site look and feel that it produces. This is it, for now.

[![Stories in Ready](https://badge.waffle.io/codeforamerica/ceviche-cms.svg?label=ready&title=Ready)](http://waffle.io/codeforamerica/ceviche-cms)